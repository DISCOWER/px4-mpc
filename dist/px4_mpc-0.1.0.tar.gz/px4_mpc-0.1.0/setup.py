# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['px4_mpc', 'px4_mpc.controllers', 'px4_mpc.models', 'px4_mpc.simulation']

package_data = \
{'': ['*']}

install_requires = \
['casadi==3.5.5',
 'matplotlib>=3.3.2,<4.0.0',
 'numpy>=1.19.2,<1.23',
 'pyyaml>=5.3.1,<6.0.0']

entry_points = \
{'console_scripts': ['astrobee_demo = nodes.astrobee_demo:main']}

setup_kwargs = {
    'name': 'px4-mpc',
    'version': '0.1.0',
    'description': 'A PX4 sample interface for MPC controllers.',
    'long_description': None,
    'author': 'Jaeyoung Lim',
    'author_email': 'jaeyoung.lim@ethz-asl.ch>, Pedro Roque <padr@kth.se',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
